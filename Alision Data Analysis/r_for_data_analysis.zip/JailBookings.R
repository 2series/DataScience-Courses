library(plotly)
library(plyr)
library(dplyr)
library(lubridate)

Sys.setenv("plotly_username"="drcrook")
Sys.setenv("plotly_api_key"="ze0kqy9hpo")

#Read Data in.
correctionsInit = read.csv("C:\\data\\jailbookings.csv")
correctionsInit = correctionsInit %>% tbl_df()
corrections = correctionsInit

#Number of Charges we want to display
#ie top 10.
numCharges = 10

#Questions 
corrections$BookDate = as.Date(corrections$BookDate, format = "%m/%d/%Y")
#
#Rework some of the labelling.
#
ChargeLUT = c("BENCH WARRANT" = "Misc. Warrants",
              "PROBATION WARRANT" = "Misc. Warrants",
              "OUT-OF-CNTY/WARRANT" = "Misc. Warrants",
              "ALIAS CAPIAS" = "Misc. Warrants",
              "ASSAULT/AGGRAVATED" = "Assault",
              "DOMESTIC VIOL WARRNT" = "Misc. Warrants",
              "GRAND THEFT/ARM/CONS" = "Grand Theft",
              "GRAND THEFT 2ND DEG" = "Grand Theft",
              "GRAND THEFT 3RD DEG" = "Grand Theft",
              "COKE/SELL/DEL/W/INT" = "Drug Traffic",
              "CONT SUB/SELL/DEL" = "Drug Traffic",
              "DWLS/HABITUAL" = "Drivers Lisence",
              "DWLS/KNOWINGLY" = "Drivers Lisence",
              "CANN/TRF/25-2000LBS" = "Drug Traffic",
              "CANN/POSN/-20/ATTEMP" = "Drug Possession",
              "DWLS/3RD & SUBS OFFN" = "Drivers Lisence",
              "NO VALID DRIVERS LIC" = "Drivers Lisence",
              "CANNABIS/POSN/0-20" = "Drug Possession",
              "COCAINE/POSSESSION" = "Drug Possession",
              "ALC BEV/DRK IN PUBLC" = "Disorderly in Public",
              "DISORDERLY CONDUCT" = "Disorderly in Public",
              "PETIT THEFT" = "Theft",
              "PETIT THEFT 1D" = "Theft",
              "ASSAULT/AGG/FIREARM" = "Armed Assault",
              "ASSAULT/AGG/DWEAP" = "Armed Assault",
              "NO VALID DRIVERS LIC" = "Drivers Lisence",
              "GRD THEFT/3D/VEHICLE" = "Grand Theft",
              "CONT SUBS/POSS" = "Drug Possession",
              "ALCOHOL/PUB/MIA BCH" = "Disorderly in Public",
              "DL/EXPIRED 6 MTHS+" = "Drivers Lisence",
              "ALC/OPN CNTR/POSN" = "Drug Possession",
              "INDECENT EXPOSURE" = "Disorderly in Public",
              "DISORDERLY INTOX" = "Disorderly in Public",
              "RESIST OFF W/O VIOL" = "Resist Officer",
              "BATTERY/AGGRAVATED" = "Battery",
              "LOITERING OR PROWL" = "Loitering",
              "ARREST WARRANT" = "Misc. Warrants",
              "ROBBERY/STRONGARM" = "Theft",
              "RETAIL THEFT/300>" = "Theft",
              "BATTERY" = "Battery",
              "BATT/DOM/STRANGLE" = "Battery",
              "DRUG PARAPHERNA/POSN" = "Drug Possession",
              "TRES PROP/AFTER WARN" = "Misdemeanor",
              "BURGLARY/UNOCC CONVY" = "Theft",
              "CANN/SELL/DEL/PSNW/I" = "Drug Traffic",
              "BATTERY/LEO/COR/FIRE" = "Battery",
              "FUG WARR/OUT O STATE" = "Misc. Warrants",
              "TRESPASS/STRUC/UNOCC" = "Misdemeanor",
              "DIS COND/ESTAB" = "Disorderly in Public",
              "RECKLESS DRIVING" = "Reckless Driving",
              "RBRY/ARM/FA/DW - PBL" = "Theft",
              "BURGLARY/OCC/DWELL" = "Theft",
              "BATTERY/AGG/DWEAP" = "Armed Assault",
              "DUI/DAM/PROP/PERSON" = "DUI",
              "ALCOHOL/CURB DRNKNG" = "Disorderly in Public",
              "DUI/BREATH LEVEL" = "DUI",
              "BATTERY/FELONY" = "Battery",
              "ASSAULT" = "Assault",
              "PROBATION VIOLATION" = "Probation",
              "CRIM MIS/1000+" = "Misdemeanor",
              "CRIM MIS/200-1000" = "Misdemeanor",
              "BURGLARY/UNOCC/DWELL" = "Theft",
              "WRIT/BODILY ATTACH" = "Misc. Warrants",
              "PANHANDLING/BEG/SOL" = "Misdemeanor",
              "CONCEALED F/A /CARRY" = "Weapons",
              "CANNABIS/POSN/20+" = "Drug Possession",
              "BURGLARY/UNOCC/PREJU" = "Theft",
              "PROST/COMMIT/ENGAGE" = "Prostitution",
              "HOLD FOR AGENCY" = "Misc. Warrants",
              "BATTERY/AGG/PREGNANT" = "Battery",
              "LSA/PROP DAMAGE" = "Reckless Driving",
              "PANHANDLE/AGGRESV" = "Misdemeanor",
              "ALCOHOL/CONSUM/STORE" = "Disorderly in Public",
              "CRIM MIS/0-200" = "Misdemeanor",
              "FA/WEAP/POSN/FEL/DEL" = "Weapons",
              "BURGLARY/UNOCC/STRUC" = "Theft",
              "UTTERING/CHECK" = "Forgery",
              "DOM VIOL/INJUNC VIOL" = "Assault",
              "GT 3RD/VEHICLE/CONS" = "Grand Theft",
              "FLEE/ELUDE PO" = "Fleeing",
              "BURG/ASLT/BATT - PBL" = "Theft",
              "BATTERY/ELDERLY" = "Battery",
              "PARK/ENT AFT HRS" = "Misdemeanor",
              "BATTERY/AGG/HRM/WEAP" = "Armed Assault",
              "STOLEN PROP/DEAL IN" = "Theft",
              "TRESP/STRUC/OCC/WARN" = "Misdemeanor",
              "HER/SELL/DEL W/INT" = "Drug Traffic",
              "BUSINESS W/O LIC" = "Bussiness Offense",
              "PETIT THEFT 2> CONV" = "Theft",
              "HOLD/CORRECTIONS" = "Misc. Warrants",
              "PANHANDLE/AGGR/OBSTR" = "Misdemeanor",
              "BATTERY/ATTEMPT" = "Assault",
              "ORGANIZED FRD/0-20K" = "Business Offense",
              "RESIST OFF W/VIOL" = "Resist Officer",
              "FLS NAME/ID/AFT ARRE" = "Other",
              "RETAIL THFT/PRI CON" = "Theft",
              "BOATING UNDER INFLU" = "DUI",
              "ATT FEL MUR/DLY WEA" = "Armed Assault"
) 
#Rename for real.
corrections$Charge1 = corrections$Charge1 %>%
  revalue(ChargeLUT)

#What are the top issues
#aside from warrants.
topCharges = corrections %>%
  filter(Charge1 != "") %>%
  filter(Charge1 != "Misc. Warrants") %>%
  group_by(Charge1) %>%
  summarise(
    totalCharge1 = n()
  ) %>%
  top_n(numCharges, totalCharge1) %>%
  arrange(desc(totalCharge1))

#Get data together and in good display format
d = corrections %>%
  mutate(
    bookYear = year(BookDate),
    bookMonth = ordered(months(BookDate, abbreviate = TRUE), month.abb)
  ) %>%
  filter(Charge1 != "") %>%
  filter(Charge1 != "Misc. Warrants") %>%
  group_by(bookYear, bookMonth, Charge1) %>%
  summarise(
    chargeObs = n() / 1000
  ) %>%
  mutate(
    total = sum(chargeObs)
  ) %>%
  filter(Charge1 %in% topCharges$Charge1)

#Create Stacked Faceted Interactive Plot.
p = d %>%
  ggplot(aes(x = factor(bookMonth), y = chargeObs, fill = factor(Charge1))) +
  geom_bar(position = "stack", stat = "identity") +
  facet_wrap(~ bookYear) +
  ggtitle("Miami Jail Bookings") +
  labs(y="Bookings (in thousands)", x="Year/Month") +
  scale_fill_brewer(palette="Spectral")
ggplotly(p)

#Draw a professional chart
# First re-order the levels for charges in descending order
d$Charge1 = factor(d$Charge1, levels = topCharges$Charge1)
p = d %>%
  ggplot(aes(x = factor(bookMonth), y = chargeObs, fill = factor(Charge1))) +
  geom_bar(position = "stack", stat = "identity", aes(text = paste(Charge1, "-", bookMonth, "- Bookings: ", chargeObs))) +
  facet_wrap(~ bookYear) +
  scale_x_discrete(breaks = levels(d$bookMonth)[seq(1, length(d$bookMonth), 2)]) +
  ggtitle("Top 10 Miami Jail Bookings") +
  labs(y="Bookings (thousands)", x="Date") +
  scale_fill_brewer(palette="Spectral", name = "Charge") +
  theme(plot.title = element_text(size = rel(2)),
        panel.background = element_rect(fill = "white"),
        panel.grid.major = element_line(colour = "#eaeded"),
        strip.background = element_rect(fill = "#eaeded", size = 1),
        axis.title.y = element_text(size = rel(1.25), angle = 90),
        axis.title.x = element_text(size = rel(1.25), angle = 0),
        strip.text.x = element_text(size = rel(1.5))
  )
p = ggplotly(p)
p

plotly_POST(p, filename = "blog/MiamiJailBookings_5_2_2016")

###########################
# Adding for "All Others" #
###########################
d.Other = d %>% 
  select(bookYear, bookMonth) %>%
  distinct() %>%
  mutate(
    Charge1 = "Other",
    chargeObs = 0,
    total = 0
  )

for(i in 1 : nrow(d.Other)){
  year = d.Other[i,]$bookYear
  month = d.Other[i,]$bookMonth
  temp = d %>%
    filter(bookYear == year & bookMonth == month)
  d.Other[i,]$chargeObs = temp[1,]$total - sum(temp$chargeObs)
  d.Other[i,]$total = temp[1,]$total
}

d2 = rbind(d, d.Other)

