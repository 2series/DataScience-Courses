install.packages("ggvis")
install.packages("ggplot2")
install.packages("magrittr")
install.packages("shiny")
install.packages("checkpoint")
#Graphics Visualizations Package
library("ggvis") 
#Adds %>% forward pipe operator
library("magrittr") 
#contains diamonds data set and advanced visualizations
library("ggplot2")
#interactive charts and web framework
library("shiny")
library("dplyr")


#down sample for performance
diaSamp = diamonds %>% sample_frac(.25)

#basic charting
#Sample, create the initial visualization, and add scatter plot
diaSamp %>% 
  ggvis(~carat, ~price) %>% 
  layer_points()

#Sometimes, points overlap, so setting opacity helps
diaSamp %>% 
  ggvis(~carat, ~price, opacity := .5) %>% 
  layer_points()

#This is great, but its hard to tell trends
diaSamp %>% 
  ggvis(~carat, ~price) %>% 
  layer_points(opacity := .5) %>% 
  layer_smooths()

#Need to add some design in
#Blue Themed
diaSamp %>% 
  ggvis(~carat, ~price) %>% 
  layer_points(fill := "lightgreen", opacity := .5) %>% 
  layer_smooths(stroke := "darkgreen")

#Difference between := and =
#Map color of each point to the color of diamond
#Change shape to be diamond
#Add stroke
diaSamp %>% 
  ggvis(~carat, ~price) %>% 
  layer_points(fill = ~color, opacity := .5, shape := "diamond") %>% 
  layer_smooths(stroke := "black")

#Outliers affecting our chart,
#Lets ditch some
#This is a naive outlier filter,
#but does good for a demo.
diaSamp %>%
  filter(carat < 3) %>%
  ggvis(~carat, ~price) %>% 
  layer_points(fill = ~color, opacity := .5, shape := "diamond") %>% 
  layer_smooths(stroke := "black")

#Lets modify our chart a bit
#Modify the scale of the numbers
#Add annotations.
x = diaSamp
x$price = diaSamp$price / 1000
x %>%
  ggvis(~carat, ~price) %>% 
  layer_points(fill = ~color, opacity := .5, shape := "diamond") %>% 
  layer_smooths(stroke := "black") %>%
  add_axis("y", title = "price (thousands)")

#Add Interactivity for understanding
#How a single qualitative variable
#impacts our predictor lines
x %>%
  ggvis(~carat, ~price) %>% 
  layer_points(fill = 
                 input_select(label = "Choose Comparison",
                              choices = c("cut", "color", "clarity"),
                              map = as.name)
                 , opacity := .5, shape := "diamond") %>%
  layer_smooths(fill := "black") %>%
  add_axis("y", title = "price (thousands)")

#interactivity to swap x and y axis with 2 different options
diaSamp %>%
  ggvis(x = input_select(
            label = "Choose X Axis",
            choices = c('depth', 'carat'), map = as.name), 
        y = input_select(
          label = "Choose Y Axis",
          choices = c('price', 'carat'), map = as.name)) %>%
  layer_points(fill = 
                 input_select(label = "Choose Comparison",
                              choices = c("cut", "color", "clarity"),
                              map = as.name),
              opacity := .5, shape := "diamond") %>%
  add_axis("y", title = "Y Axis") %>%
  add_axis("x", title = "X Axis")


library("ggplot2")
library("dplyr")
diamonds %>% sample_frac(.01) %>% ggplot(aes(x = carat, y = price)) + geom_point()


