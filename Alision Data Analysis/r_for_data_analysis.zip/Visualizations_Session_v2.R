library(magrittr)
library(dplyr)
library(ggplot2)
library(plotly)
library(RColorBrewer)
###################
# Intro to plotly #
###################

#down sample for speed
d = diamonds %>% sample_frac(.01)

#############################
# Explore the Diamonds Data #
#############################

#View basics of data set
labels(d)

#Default Scatter Plot, Notice MODE
#Lets see price vs diamond depth
d %>%
  plot_ly(x = carat, y = price, mode = "markers")

#Adjust size a bit, 
#allows us to look at data with a different lense
d %>%
  plot_ly(x = depth, y = carat, mode = "markers", size = price)

#Prices obviously go up with carat, but depth appears to have little impact
#at least that we can tell with this view.

#Lets add some colors here
d %>%
  plot_ly(x = depth, y = carat, mode = "markers", color = cut, size = price)

#Perhaps not the most useful of all combinations
#Lets adjust
d %>% 
  plot_ly(x = carat, y = price, mode = "markers", color = cut, size = depth)
#Great, cut and size appear to have a more obvious impact on diamond price than depth.

#Not really enough though...
#Lets do faceted plots
d$cutName = as.character(d$cut)
d %>% 
    plot_ly(x = carat, y = price, mode = "markers", 
            size = depth, group = cut, 
            xaxis = paste("x", cutName)) %>%
    layout(
      yaxis = list(range = range(d$price)),
      xaxis = list(range = range(d$carat))
      ) %>%
  subplot()

#Thats ugly, so we revert to ggplot2, but push into plot_ly
p = d %>%
    ggplot(aes(x = carat, y = price, color = clarity)) +
    geom_point(aes(size = depth)) +
    facet_wrap(~cut) 
ggplotly(p)

#Thats good, but how about a line fit?
p = d %>%
  ggplot(aes(x = carat, y = price)) +
  geom_point(aes(size = depth, color = clarity, text = paste("Clarity:", clarity))) +
  geom_smooth(aes(color = cut, fill = cut)) +
  facet_wrap(~cut)
ggplotly(p) 
#We can see here that on each cut, 
#VVS1 and VS2 seem to bring the prices up, 
#while I1 and SI2 bring values down

#############
# Box Plots #
#############

#Show Distribution of diamonds
d %>%
  plot_ly(y = price, type = "box")

#Lets do a little more labeling here
d %>%
  plot_ly(y = price, type = "box") %>%
  layout(title = "Diamonds Price Distribution",
         xaxis = list(title = "Diamonds"))

#Lets see per cut
d %>%
  plot_ly(y = price, type = "box", color = cut) %>%
  layout(title = "Diamonds Price Distribution",
         xaxis = list(title = "Cut"))

#Thats cool, but I want to see the points that generated that...
d %>%
  plot_ly(y = price, type = "box", boxpoints = "all", color = cut) %>%
  layout(title = "Diamonds Price Distribution",
         xaxis = list(title = "Cut"))

#That yellowis really tough to see...and I need a theme
d %>%
  plot_ly(y = price, type = "box", boxpoints = "all", color = cut,
          colors =  "Dark2") %>%
  layout(title = "Diamonds Price Distribution",
         xaxis = list(title = "Cut")) 

#We might want to set colors manually
d %>%
  plot_ly(y = price, type = "box", boxpoints = "all", color = cut,
          colors =  c("#74a9cf", "#3690c0", "#0570b0", "#045a8d", "#023858")) %>%
  layout(title = "Diamonds Price Distribution",
         xaxis = list(title = "Cut")) 

#Lets do grouped actions
d %>%
  plot_ly(x = clarity, y = price, color = cut, type = "box",
        colors =  c("#74a9cf", "#3690c0", "#0570b0", "#045a8d", "#023858")) %>%
  layout(boxmode = "group")

#Too many x axis options, swap color and x
d %>%
  plot_ly(x = cut, y = price, color = clarity, type = "box",
          colors =  "Set1") %>%
  layout(boxmode = "group")

####################
# Dodged Bar Chart #
####################

d %>%
  group_by(cut, clarity) %>%
  summarise(
    count = n()
  ) %>%
  plot_ly(x = cut, y = count, type = "bar", color = clarity)



##################
# Multiple Plots #
##################

###############
# with Plotly #
###############
d2 = d[order(d$carat),]

m = loess(price ~ carat, data = d2)
f = with(predict(m, se = TRUE), data.frame(fit, se.fit))
lColor = list(
            color = toRGB("gray90", alpha = 0.3),
            fillcolor = toRGB("gray90", alpha = 0.3)
          )
  
d2 %>%
  plot_ly(x = carat, y = price, mode = "markers", name = "raw data",
             text = rownames(diamonds), color = cut) %>%
  add_trace(y = fit, mode = "lines", data = f) %>%
  add_trace(data = f, y = fit + 1.96 * se.fit, mode = "lines",
            fill = "tonexty", line = lColor) %>%
  add_trace(data = f, y = fit - 1.96 * se.fit, mode = "lines",
            fill = "tonexty", line = lColor)

################
# With GGplot2 #
################
p = ggplot(data = d, aes(x = carat, y = price)) +
  geom_smooth(colour = "black", aes(text = "smoothed")) +
  geom_point(aes(text = paste("Clarity:", clarity),  color = cut, alpha = 0.5), size = 2) 
ggplotly(p)
  
  